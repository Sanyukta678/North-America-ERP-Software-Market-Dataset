# North America ERP Software Market Dataset

This dataset contains structured information extracted from the publicly available summary of the North America ERP Software Market report (SE3605).  
It includes market size values, growth projections, and segmentation data based only on publicly visible information.

## Files Included
- `market_overview.csv`
- `segmentation.csv`
- `metadata.json`

## Notes
This dataset is intended for research and educational purposes and does not contain proprietary report contents.
